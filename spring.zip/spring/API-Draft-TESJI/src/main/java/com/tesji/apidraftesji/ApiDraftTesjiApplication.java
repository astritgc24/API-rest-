package com.tesji.apidraftesji;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiDraftTesjiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiDraftTesjiApplication.class, args);
	}

}
