package com.tesji.apidraftesji.service;

import com.tesji.apidraftesji.model.DatosApiDraft;
import com.tesji.apidraftesji.repository.CrudApiDrafTesjiRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Optional;

@Service
public class ApiDraftServiveImplementar implements ApiDraftService{
    //Inyectar un objeto de la clase Repository que tiene las operaciones CRUD.

    @Autowired
     CrudApiDrafTesjiRepository crudApiDrafTesjiRepository;

    @Override
    public ArrayList<DatosApiDraft> mostrarTodosJugadores() {
        return (ArrayList<DatosApiDraft>) crudApiDrafTesjiRepository.findAll();
    }

    @Override
    public Optional<DatosApiDraft> mostrarJugadorPorId(long id) {
        return crudApiDrafTesjiRepository.findById(id);
    }

    @Override
    public DatosApiDraft registrarJugador(DatosApiDraft jugador) {
        return crudApiDrafTesjiRepository.save(jugador);
    }

    @Override
    public boolean borrarJugador(long id) {
        return false;
    }
}
