package com.tesji.apidraftesji.repository;

import com.tesji.apidraftesji.model.DatosApiDraft;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

//Hereda las operaciones CRUD de la API a traves de CrudRepository.
@Repository
public interface CrudApiDrafTesjiRepository extends CrudRepository<DatosApiDraft,Long> {
}
