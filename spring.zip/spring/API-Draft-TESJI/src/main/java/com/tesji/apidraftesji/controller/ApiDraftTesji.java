package com.tesji.apidraftesji.controller;
// Define el acceso a la API por medio de una URI
//Definir los enf-points (peticiones http)

import com.tesji.apidraftesji.model.DatosApiDraft;
import com.tesji.apidraftesji.service.ApiDraftService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

@RestController //Expone como un servicio API REST no usages
@RequestMapping("/api-draftesji")
public class ApiDraftTesji {


    //Inyectar un objeto de Service que tiene las operaciones CRUD
    @Autowired
    ApiDraftService apiDraftService;

    //Definir los end-points
    @GetMapping("/get-prueba")
    public String getPrueba(){
        return "Funciona!! Bienvenido a API DRAFT TESJI";
    }
    @GetMapping("/ver-todosjugadores")
    public ArrayList<DatosApiDraft> verTodosJugadores(){
        return apiDraftService.mostrarTodosJugadores();
    }
}
