package com.tesji.apidraftesji;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiDraftTesjiApplicationTests {

	@Test
	void contextLoads() {
	}

}
